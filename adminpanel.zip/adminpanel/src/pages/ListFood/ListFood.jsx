import React from 'react';

const ListFood = () => {
  return (
    <div>List Food</div>
  )
}

export default ListFood;