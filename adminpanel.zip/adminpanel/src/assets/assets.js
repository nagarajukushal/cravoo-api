import logo from './logo.png';
import parcel from './parcel.png';
import upload from './upload.png';

export const assets = {
    logo,
    parcel,
    upload
};